<?php
include 'koneksi.php';

$username = trim($_POST['username'] ?? '');
$email    = trim($_POST['email'] ?? '');
$password = trim($_POST['password'] ?? '');
$role     = trim($_POST['role'] ?? '');

if ($username === '' || $email === '' || $password === '' || $role === '') {
    header("Location: register.html?error=1");
    exit;
}

$hashed = password_hash($password, PASSWORD_BCRYPT);

// simpan
$stmt = $conn->prepare("INSERT INTO users (name, email, username, password, role)
                        VALUES (?, ?, ?, ?, ?)");
$name = $username;
$stmt->bind_param("sssss", $name, $email, $username, $hashed, $role);

if ($stmt->execute()) {
    echo "<script>alert('Registrasi berhasil! Silakan login.'); window.location='login.html';</script>";
} else {
    header("Location: register.html?error=1");
}
