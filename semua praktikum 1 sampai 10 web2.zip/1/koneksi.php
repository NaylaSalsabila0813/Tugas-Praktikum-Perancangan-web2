<?php
// KONFIGURASI DATABASE
$host     = "localhost";   // biasanya: localhost
$user     = "root";        // default XAMPP: root
$password = "";            // default XAMPP: kosong
$dbname   = "db_toko_online";  // sesuaikan dengan nama database kamu

// BUAT KONEKSI
$conn = new mysqli($host, $user, $password, $dbname);

// CEK KONEKSI
if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// SET CHARSET (BIAR UTF-8, AMAN UNTUK TEKS INDONESIA/KOREA)
$conn->set_charset("utf8mb4");
?>
