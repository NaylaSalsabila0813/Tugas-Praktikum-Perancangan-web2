<?php
session_start();
include 'koneksi.php';

// Pastikan hanya bisa diakses lewat POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.html');
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = trim($_POST['password'] ?? '');

// Jika kosong, kirim balik ke form dengan error
if ($username === '' || $password === '') {
    header("Location: login.html?error=1");
    exit;
}

// Ambil user berdasarkan username ATAU email
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
$stmt->bind_param("ss", $username, $username);
$stmt->execute();
$result = $stmt->get_result();
$user   = $result->fetch_assoc();
$stmt->close();

// Jika user tidak ditemukan
if (!$user) {
    header("Location: login.html?error=1");
    exit;
}

$stored = $user['password'];
$valid  = false;

// 1. Coba cek password hash (bcrypt, dll)
if (password_verify($password, $stored)) {
    $valid = true;
}
// 2. Kalau ternyata password di DB masih plain text (misal: "123")
//    login-kan sekali, lalu otomatis di-hash dan disimpan ulang
elseif ($password === $stored) {
    $valid = true;

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $upd  = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $upd->bind_param("si", $hash, $user['id']);
    $upd->execute();
    $upd->close();
}

// Kalau password tidak valid
if (!$valid) {
    header("Location: login.html?error=1");
    exit;
}

// SET SESSION
$_SESSION['user_id']  = $user['id'];
$_SESSION['username'] = $user['username'];
$_SESSION['role']     = $user['role'];

// Redirect berdasarkan role
if ($user['role'] === 'admin') {
    header("Location: admin/admin_dashboard.php");
} else {
    header("Location: index.php");
}
exit;
