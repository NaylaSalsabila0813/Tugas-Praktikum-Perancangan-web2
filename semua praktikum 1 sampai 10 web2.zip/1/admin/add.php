<?php
include 'admin_header.php';

// ambil kategori untuk dropdown
$cats = $conn->query("SELECT id, name FROM categories ORDER BY name ASC");

// simpan jika submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id = $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null;
    $name        = trim($_POST['name']);
    $slug        = trim($_POST['slug']);
    $brand       = trim($_POST['brand']);
    $description = trim($_POST['description']);
    $price       = (float)$_POST['price'];
    $stock       = (int)$_POST['stock'];

    // default: tidak ada gambar
    $imageFileName = null;

    // === HANDLE UPLOAD GAMBAR ===
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $tmpName  = $_FILES['image']['tmp_name'];
        $origName = $_FILES['image']['name'];

        // ambil ekstensi
        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($ext, $allowed)) {
            echo "<div class='mb-4 text-red-600'>Format gambar tidak didukung. Gunakan JPG, PNG, atau WEBP.</div>";
        } else {
            // bikin nama file unik
            $imageFileName = date('YmdHis') . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $origName);

            // folder tujuan (dari folder /admin, jadi pakai ../uploads)
            $targetDir  = '../uploads/';
            $targetPath = $targetDir . $imageFileName;

            // pastikan folder uploads ada
            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0777, true);
            }

            if (!move_uploaded_file($tmpName, $targetPath)) {
                echo "<div class='mb-4 text-red-600'>Gagal mengupload gambar.</div>";
                $imageFileName = null; // supaya tidak disimpan kalau gagal
            }
        }
    }

    if ($name === '' || $slug === '') {
        echo "<div class='mb-4 text-red-600'>Nama dan slug wajib diisi.</div>";
    } else {
        $stmt = $conn->prepare("INSERT INTO products 
            (category_id, name, slug, brand, description, price, stock, image) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");

        // kalau tidak ada gambar, simpan null
        $stmt->bind_param(
            "issssdis",
            $category_id,
            $name,
            $slug,
            $brand,
            $description,
            $price,
            $stock,
            $imageFileName
        );

        if ($stmt->execute()) {
            echo "<script>alert('Produk berhasil ditambah!'); window.location='admin_products.php';</script>";
            exit;
        } else {
            echo "<div class='mb-4 text-red-600'>Gagal menyimpan: ".htmlspecialchars($conn->error)."</div>";
        }
    }
}
?>

<h1 class="text-2xl font-bold text-pink-700 mb-4">Tambah Produk</h1>

<form method="POST" enctype="multipart/form-data" class="space-y-4">
    <div>
        <label class="block text-sm font-medium mb-1">Kategori</label>
        <select name="category_id" class="w-full border rounded px-3 py-2">
            <option value="">-- Pilih Kategori --</option>
            <?php if ($cats): ?>
                <?php while($c = $cats->fetch_assoc()): ?>
                    <option value="<?= $c['id']; ?>"><?= htmlspecialchars($c['name']); ?></option>
                <?php endwhile; ?>
            <?php endif; ?>
        </select>
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Nama Produk</label>
        <input type="text" name="name" class="w-full border rounded px-3 py-2" required>
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Slug (tanpa spasi)</label>
        <input type="text" name="slug" class="w-full border rounded px-3 py-2" required>
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Brand</label>
        <input type="text" name="brand" class="w-full border rounded px-3 py-2">
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Deskripsi</label>
        <textarea name="description" rows="3" class="w-full border rounded px-3 py-2"></textarea>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Harga (Rp)</label>
            <input type="number" step="100" name="price" class="w-full border rounded px-3 py-2" required>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Stok</label>
            <input type="number" name="stock" class="w-full border rounded px-3 py-2" required>
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Foto Produk</label>
        <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp"
               class="w-full border rounded px-3 py-2 bg-white">
        <p class="text-xs text-gray-500 mt-1">Format yang diperbolehkan: JPG, JPEG, PNG, WEBP.</p>
    </div>

    <div class="flex justify-between mt-4">
        <a href="admin_products.php" class="text-gray-600 hover:underline">← Kembali</a>
        <button type="submit" class="bg-pink-600 text-white px-4 py-2 rounded hover:bg-pink-700">
            Simpan
        </button>
    </div>
</form>

</main>
</body>
</html>
