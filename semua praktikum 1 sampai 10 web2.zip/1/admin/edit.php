<?php
include 'admin_header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header("Location: admin_products.php");
    exit;
}

// ambil produk dulu (supaya tahu foto lama)
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ? LIMIT 1");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    echo "<p>Produk tidak ditemukan.</p></main></body></html>";
    exit;
}

// ambil kategori
$cats = $conn->query("SELECT id, name FROM categories ORDER BY name ASC");

// jika submit update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $category_id = $_POST['category_id'] !== '' ? (int)$_POST['category_id'] : null;
    $name        = trim($_POST['name']);
    $slug        = trim($_POST['slug']);
    $brand       = trim($_POST['brand']);
    $description = trim($_POST['description']);
    $price       = (float)$_POST['price'];
    $stock       = (int)$_POST['stock'];

    // default pakai foto lama
    $imageFileName = $product['image'];

    // jika ada upload foto baru
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $tmpName  = $_FILES['image']['tmp_name'];
        $origName = $_FILES['image']['name'];

        $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'webp'];

        if (!in_array($ext, $allowed)) {
            echo "<div class='mb-4 text-red-600'>Format gambar tidak didukung. Gunakan JPG, PNG, atau WEBP.</div>";
        } else {
            // nama file unik
            $imageFileName = date('YmdHis') . '_' . preg_replace('/[^a-zA-Z0-9_\.-]/', '_', $origName);

            $targetDir  = '../uploads/';
            $targetPath = $targetDir . $imageFileName;

            if (!is_dir($targetDir)) {
                mkdir($targetDir, 0777, true);
            }

            if (!move_uploaded_file($tmpName, $targetPath)) {
                echo "<div class='mb-4 text-red-600'>Gagal mengupload gambar baru, foto lama tetap digunakan.</div>";
                $imageFileName = $product['image']; // fallback ke lama
            } else {
                // kalau mau hapus foto lama dari server, bisa aktifkan ini:
                // if ($product['image'] && file_exists($targetDir . $product['image'])) {
                //     @unlink($targetDir . $product['image']);
                // }
            }
        }
    }

    if ($name === '' || $slug === '') {
        echo "<div class='mb-4 text-red-600'>Nama dan slug wajib diisi.</div>";
    } else {
        $stmtUp = $conn->prepare("UPDATE products
            SET category_id = ?, name = ?, slug = ?, brand = ?, description = ?, price = ?, stock = ?, image = ?
            WHERE id = ?");
        // i s s s s d i s i  → "issssdisi"
        $stmtUp->bind_param(
            "issssdiss",
            $category_id,
            $name,
            $slug,
            $brand,
            $description,
            $price,
            $stock,
            $imageFileName,
            $id
        );

        if ($stmtUp->execute()) {
            echo "<script>alert('Produk berhasil diupdate!'); window.location='admin_products.php';</script>";
            exit;
        } else {
            echo "<div class='mb-4 text-red-600'>Gagal update: ".htmlspecialchars($conn->error)."</div>";
        }
    }
}
?>

<h1 class="text-2xl font-bold text-pink-700 mb-4">Edit Produk</h1>

<form method="POST" enctype="multipart/form-data" class="space-y-4">
    <div>
        <label class="block text-sm font-medium mb-1">Kategori</label>
        <select name="category_id" class="w-full border rounded px-3 py-2">
            <option value="">-- Pilih Kategori --</option>
            <?php if ($cats): ?>
                <?php while($c = $cats->fetch_assoc()): ?>
                    <option value="<?= $c['id']; ?>"
                        <?= $product['category_id'] == $c['id'] ? 'selected' : ''; ?>>
                        <?= htmlspecialchars($c['name']); ?>
                    </option>
                <?php endwhile; ?>
            <?php endif; ?>
        </select>
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Nama Produk</label>
        <input type="text" name="name" class="w-full border rounded px-3 py-2"
               value="<?= htmlspecialchars($product['name']); ?>" required>
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Slug</label>
        <input type="text" name="slug" class="w-full border rounded px-3 py-2"
               value="<?= htmlspecialchars($product['slug']); ?>" required>
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Brand</label>
        <input type="text" name="brand" class="w-full border rounded px-3 py-2"
               value="<?= htmlspecialchars($product['brand']); ?>">
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Deskripsi</label>
        <textarea name="description" rows="3" class="w-full border rounded px-3 py-2"><?= htmlspecialchars($product['description']); ?></textarea>
    </div>

    <div class="grid grid-cols-2 gap-4">
        <div>
            <label class="block text-sm font-medium mb-1">Harga (Rp)</label>
            <input type="number" step="100" name="price" class="w-full border rounded px-3 py-2"
                   value="<?= $product['price']; ?>" required>
        </div>
        <div>
            <label class="block text-sm font-medium mb-1">Stok</label>
            <input type="number" name="stock" class="w-full border rounded px-3 py-2"
                   value="<?= $product['stock']; ?>" required>
        </div>
    </div>

    <div>
        <label class="block text-sm font-medium mb-1">Foto Produk (boleh kosong jika tidak ganti)</label>
        <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp"
               class="w-full border rounded px-3 py-2 bg-white">
        <?php if (!empty($product['image'])): ?>
            <p class="text-xs text-gray-500 mt-1">Foto sekarang:</p>
            <img src="../uploads/<?= htmlspecialchars($product['image']); ?>" alt="Foto produk"
                 class="mt-1 h-24 rounded border">
        <?php endif; ?>
    </div>

    <div class="flex justify-between mt-4">
        <a href="admin_products.php" class="text-gray-600 hover:underline">← Kembali</a>
        <button type="submit" class="bg-pink-600 text-white px-4 py-2 rounded hover:bg-pink-700">
            Update
        </button>
    </div>
</form>

</main>
</body>
</html>
