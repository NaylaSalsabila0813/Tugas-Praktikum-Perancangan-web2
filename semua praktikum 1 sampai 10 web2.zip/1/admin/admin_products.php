<?php
include 'admin_header.php';

// ambil semua produk + kategori
$sql = "SELECT p.*, c.name AS category_name
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        ORDER BY p.id DESC";
$products = $conn->query($sql);
?>

    <div class="flex justify-between items-center mb-4">
        <h1 class="text-2xl font-bold text-pink-700">Manajemen Produk</h1>
        <a href="add.php" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
            + Tambah Produk
        </a>
    </div>

    <table class="min-w-full text-sm border border-gray-200">
        <thead class="bg-pink-100">
            <tr>
                <th class="border px-2 py-1">ID</th>
                <th class="border px-2 py-1">Nama</th>
                <th class="border px-2 py-1">Kategori</th>
                <th class="border px-2 py-1">Brand</th>
                <th class="border px-2 py-1">Harga</th>
                <th class="border px-2 py-1">Stok</th>
                <th class="border px-2 py-1">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($products && $products->num_rows > 0): ?>
                <?php while($row = $products->fetch_assoc()): ?>
                    <tr class="hover:bg-pink-50">
                        <td class="border px-2 py-1 text-center"><?= $row['id']; ?></td>
                        <td class="border px-2 py-1"><?= htmlspecialchars($row['name']); ?></td>
                        <td class="border px-2 py-1"><?= htmlspecialchars($row['category_name'] ?? '-'); ?></td>
                        <td class="border px-2 py-1"><?= htmlspecialchars($row['brand']); ?></td>
                        <td class="border px-2 py-1">Rp <?= number_format($row['price'], 0, ',', '.'); ?></td>
                        <td class="border px-2 py-1 text-center"><?= $row['stock']; ?></td>
                        <td class="border px-2 py-1 text-center space-x-2">
                            <a href="edit.php?id=<?= $row['id']; ?>"
                               class="text-blue-600 hover:underline">Edit</a>
                            <a href="delete.php?id=<?= $row['id']; ?>"
                               class="text-red-600 hover:underline"
                               onclick="return confirm('Yakin hapus produk ini?');">
                               Hapus
                            </a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td class="border px-2 py-2 text-center text-gray-500" colspan="7">
                        Belum ada produk.
                    </td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

</main>
</body>
</html>
