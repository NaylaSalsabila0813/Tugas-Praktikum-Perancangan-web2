<?php
// SELALU MULAI SESSION
session_start();

// SESUAIKAN PATH KONEKSI (karena file ini di folder /admin)
include '../koneksi.php';

// CEK SUDAH LOGIN & ROLE ADMIN
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    // kalau belum login sebagai admin, kembalikan ke login
    header("Location: ../login.html");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel | Seoul Beats & Smtown Store</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body { font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; }
    </style>
</head>
<body class="bg-pink-50">

<nav class="bg-white shadow-md px-6 py-3 flex justify-between items-center">
    <div class="font-bold text-pink-700 text-xl">
        Admin Panel
    </div>
    <div class="space-x-4">
        <a href="admin_dashboard.php" class="text-pink-700 hover:underline">Dashboard</a>
        <a href="admin_products.php" class="text-pink-700 hover:underline">Produk</a>
        <a href="../index.php" class="text-gray-600 hover:underline">Lihat Website</a>
        <a href="../logout.php" class="bg-pink-600 text-white px-3 py-1 rounded hover:bg-pink-700">Logout</a>
    </div>
</nav>

<main class="max-w-5xl mx-auto mt-8 mb-16 bg-white rounded-xl shadow p-6">
