<?php include 'admin_header.php'; ?>

    <h1 class="text-2xl font-bold text-pink-700 mb-4">
        Selamat datang, <?= htmlspecialchars($_SESSION['username']); ?> 👑
    </h1>
    <p class="text-gray-700 mb-4">
        Ini adalah dashboard admin. Kamu bisa mengelola produk melalui menu <b>Produk</b>.
    </p>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
        <div class="p-4 rounded-lg bg-pink-100">
            <h2 class="font-semibold text-pink-700 mb-2">Menu Cepat</h2>
            <ul class="list-disc list-inside text-sm text-gray-700">
                <li><a class="text-pink-600 hover:underline" href="admin_products.php">Kelola Produk</a></li>
            </ul>
        </div>
    </div>

</main>
</body>
</html>
