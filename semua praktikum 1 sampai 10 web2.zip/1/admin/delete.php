<?php
include 'admin_header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if ($id <= 0) {
    header("Location: admin_products.php");
    exit;
}

$stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo "<script>alert('Produk berhasil dihapus!'); window.location='admin_products.php';</script>";
} else {
    echo "<script>alert('Gagal menghapus produk'); window.location='admin_products.php';</script>";
}
