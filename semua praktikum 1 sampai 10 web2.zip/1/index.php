<?php
session_start();
include 'koneksi.php'; // koneksi database
$isLoggedIn = isset($_SESSION['user_id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seoul Beats & Smtown Store</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">

    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
    </style>
</head>

<body class="bg-pink-50">

    <!-- NAVBAR -->
    <nav class="bg-white shadow-md py-4 px-8 fixed top-0 left-0 w-full z-50">
        <div class="container mx-auto flex items-center justify-between">

            <!-- Logo -->
            <h1 class="text-2xl font-bold text-pink-700">
                Seoul Beats & Smtown Store
            </h1>

            <!-- Menu -->
            <div class="hidden md:flex space-x-8 text-lg font-semibold">
                <a href="#home" class="text-pink-700 hover:text-pink-900">Home</a>
                <a href="#products" class="text-pink-700 hover:text-pink-900">Products</a>
                <a href="#about" class="text-pink-700 hover:text-pink-900">About</a>
                <a href="#contact" class="text-pink-700 hover:text-pink-900">Contact</a>

                <!-- Tombol Login / Logout -->
                <?php if ($isLoggedIn): ?>
                    <a href="logout.php" class="bg-pink-600 text-white px-4 py-2 rounded-lg hover:bg-pink-700">
                        Logout
                    </a>
                <?php else: ?>
                    <a href="login.html" class="bg-pink-600 text-white px-4 py-2 rounded-lg hover:bg-pink-700">
                        Login
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- HERO SECTION -->
    <section id="home" class="pt-32 pb-20 text-center px-4">
        <h2 class="text-5xl font-extrabold text-pink-700">
            Welcome to Seoul Beats & Smtown Merch
        </h2>
        <p class="mt-4 text-xl text-pink-600">
            Official merchandise dari NCT, SEVENTEEN, Stray Kids, BoyNextDoor, dan lainnya!
        </p>

        <!-- Shop Now: scroll ke #products -->
        <a href="#products">
            <button class="mt-6 bg-pink-600 text-white px-10 py-3 rounded-full text-lg hover:bg-pink-700">
                Shop Now
            </button>
        </a>

        <img src="WhatsApp Image 2025-06-17 at 10.52.44.jpeg"
             class="mt-10 mx-auto rounded-2xl shadow-lg w-3/4 md:w-1/2">
    </section>

    <!-- PRODUCT SECTION -->
    <section id="products" class="py-20 px-6">
        <h2 class="text-4xl text-center font-bold text-pink-700 mb-10">Featured Products</h2>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 container mx-auto">

            <!-- Card 1 (STATIC) -->
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <img src="PC NCT.jpeg" class="rounded-lg">
                <h3 class="text-xl font-semibold text-pink-700 mt-4">NCT Dream Photocard</h3>
                <p class="mt-2 text-gray-600">Limited edition photocard pack.</p>
                <!-- harga disembunyikan, hanya di data-price -->
                <button
                    class="mt-4 bg-pink-600 text-white w-full py-2 rounded-lg hover:bg-pink-700 add-to-cart-btn"
                    data-name="NCT Dream Photocard"
                    data-price="15.00"
                >
                    Add to Cart
                </button>
            </div>

            <!-- Card 2 (STATIC) -->
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <img src="Hoodie Woozi.jpeg" class="rounded-lg">
                <h3 class="text-xl font-semibold text-pink-700 mt-4">Hoodie Seventeen</h3>
                <p class="mt-2 text-gray-600">Hoodie terbaru dari seventeen.</p>
                <button
                    class="mt-4 bg-pink-600 text-white w-full py-2 rounded-lg hover:bg-pink-700 add-to-cart-btn"
                    data-name="Hoodie Seventeen"
                    data-price="45.00"
                >
                    Add to Cart
                </button>
            </div>

            <!-- Card 3 (STATIC) -->
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <img src="Skzoo.jpeg" class="rounded-lg">
                <h3 class="text-xl font-semibold text-pink-700 mt-4">Skzoo Stray kids doll</h3>
                <p class="mt-2 text-gray-600">Doll stray kids yang lucu.</p>
                <button
                    class="mt-4 bg-pink-600 text-white w-full py-2 rounded-lg hover:bg-pink-700 add-to-cart-btn"
                    data-name="Skzoo Stray kids doll"
                    data-price="30.00"
                >
                    Add to Cart
                </button>
            </div>

            <!-- Card 4 (STATIC) -->
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <img src="Lighstick NCT.jpeg" class="rounded-lg">
                <h3 class="text-xl font-semibold text-pink-700 mt-4">Lighstick NCT</h3>
                <p class="mt-2 text-gray-600">Lighstick NCT ver 1 dan ver 2.</p>
                <button
                    class="mt-4 bg-pink-600 text-white w-full py-2 rounded-lg hover:bg-pink-700 add-to-cart-btn"
                    data-name="Lighstick NCT"
                    data-price="55.00"
                >
                    Add to Cart
                </button>
            </div>

            <!-- Card 5 (STATIC) -->
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <img src="pc straykids.jpeg" class="rounded-lg">
                <h3 class="text-xl font-semibold text-pink-700 mt-4">Photocard straykids</h3>
                <p class="mt-2 text-gray-600">Limited edition photocard pack.</p>
                <button
                    class="mt-4 bg-pink-600 text-white w-full py-2 rounded-lg hover:bg-pink-700 add-to-cart-btn"
                    data-name="Photocard straykids"
                    data-price="12.00"
                >
                    Add to Cart
                </button>
            </div>

            <!-- Card 6 (STATIC) -->
            <div class="bg-white p-6 rounded-xl shadow-lg">
                <img src="Lighstick Bnd.jpeg" class="rounded-lg">
                <h3 class="text-xl font-semibold text-pink-700 mt-4">Lighstick Boynextdoor</h3>
                <p class="mt-2 text-gray-600">Lighstick Boynextdoor</p>
                <button
                    class="mt-4 bg-pink-600 text-white w-full py-2 rounded-lg hover:bg-pink-700 add-to-cart-btn"
                    data-name="Lighstick Boynextdoor"
                    data-price="50.00"
                >
                    Add to Cart
                </button>
            </div>

            <!-- ==========================
                 PRODUK DARI DATABASE
                 ========================== -->
            <?php
            $resultProducts = $conn->query("SELECT * FROM products ORDER BY created_at DESC");
            if ($resultProducts && $resultProducts->num_rows > 0):
                while ($p = $resultProducts->fetch_assoc()):

                    $imgSrc = 'https://via.placeholder.com/400x400?text=No+Image';
                    if (!empty($p['image'])) {
                        $imgSrc = 'uploads/' . htmlspecialchars($p['image']);
                    }

                    // Konversi Rupiah -> Dollar (jika price di DB rupiah)
                    $priceRupiah     = (float)$p['price'];
                    $kursUsd         = 16000; // sesuaikan
                    $priceDollar     = $priceRupiah / $kursUsd;
                    $priceDollarStr  = number_format($priceDollar, 2, '.', '');
            ?>
                <div class="bg-white p-6 rounded-xl shadow-lg">
                    <img src="<?= $imgSrc; ?>" class="rounded-lg w-full h-60 object-cover">
                    <h3 class="text-xl font-semibold text-pink-700 mt-4">
                        <?= htmlspecialchars($p['name']); ?>
                    </h3>
                    <p class="mt-1 text-sm text-gray-500">
                        <?= !empty($p['brand']) ? htmlspecialchars($p['brand']) : 'K-Pop Merch'; ?>
                    </p>
                    <p class="mt-2 text-gray-600 line-clamp-2">
                        <?= htmlspecialchars($p['description'] ?? ''); ?>
                    </p>
                    <button
                        class="mt-4 bg-pink-600 text-white w-full py-2 rounded-lg hover:bg-pink-700 add-to-cart-btn"
                        data-name="<?= htmlspecialchars($p['name']); ?>" 
                        data-price="<?= $priceDollarStr; ?>"
                    >
                        Add to Cart
                    </button>
                </div>
            <?php
                endwhile;
            endif;
            ?>
        </div>
    </section>

    <!-- Cart Section -->
    <section class="mb-16 max-w-4xl mx-auto bg-white rounded-2xl shadow-lg p-10" id="cart">
        <h2 class="text-4xl font-extrabold text-pink-700 mb-8 text-center tracking-wide">
            Your Shopping Cart
        </h2>
        <div class="space-y-4" id="cart-items">
            <p class="text-pink-600 text-center text-lg">
                Your cart is empty.
            </p>
        </div>
        <div class="mt-8 hidden border-t border-pink-300 pt-6 flex justify-between items-center" id="cart-summary">
            <span class="text-2xl font-extrabold text-pink-700">
                Total:
            </span>
            <span class="text-2xl font-extrabold text-pink-600" id="cart-total">
                $0.00
            </span>
        </div>
        <div class="mt-8 text-center">
            <button class="bg-green-600 text-white px-8 py-3 rounded-full font-bold hover:bg-green-700 transition focus:outline-none focus:ring-2 focus:ring-green-600 disabled:opacity-50 disabled:cursor-not-allowed" disabled id="checkout-btn">
                Checkout
            </button>
        </div>
    </section>

    <!-- ABOUT SECTION -->
    <section id="about" class="py-20 bg-white px-6">
        <div class="container mx-auto text-center">
            <h2 class="text-4xl font-bold text-pink-700">About Us</h2>
            <p class="mt-4 text-gray-600 text-lg">
                Seoul & Beats Smtown Store adalah toko online yang menyediakan
                official K-Pop merchandise original dan berkualitas. Kami menghadirkan
                pengalaman belanja yang aman dan terpercaya untuk seluruh K-Pop fans.
            </p>
        </div>
    </section>

    <!-- CONTACT SECTION -->
    <section id="contact" class="py-20 px-6 bg-pink-100">
        <h2 class="text-4xl text-center font-bold text-pink-700">Contact Us</h2>

        <div class="container mx-auto mt-8 max-w-xl bg-white p-6 rounded-xl shadow-lg">
            <form class="space-y-4">
                <input type="text" placeholder="Your Name" class="w-full p-3 border rounded-lg">
                <input type="email" placeholder="Email" class="w-full p-3 border rounded-lg">
                <textarea placeholder="Message" class="w-full p-3 border rounded-lg h-28"></textarea>

                <button class="w-full bg-pink-600 text-white py-3 rounded-lg hover:bg-pink-700">
                    Send Message
                </button>
            </form>
        </div>
    </section>

    <!-- FOOTER -->
    <footer class="bg-white py-6 text-center shadow-inner">
        <p class="text-pink-700 font-semibold">&copy; 2025 Seoul & Beats Smtown Store. All Rights Reserved.</p>
    </footer>

    <script>
    // ===== kirim status login dari PHP ke JS =====
    const IS_LOGGED_IN = <?= $isLoggedIn ? 'true' : 'false'; ?>;

    // ===== helper format Dollar =====
    function formatDollar(value) {
        value = Number(value) || 0;
        return '$' + value.toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    // 1. Array untuk menyimpan produk di keranjang (cart)
    let cart = [];

    function updateCartDisplay() {
        const cartItemsContainer = document.getElementById('cart-items');
        const cartTotalDisplay   = document.getElementById('cart-total');
        const cartSummary        = document.getElementById('cart-summary');
        const checkoutBtn        = document.getElementById('checkout-btn');
        let total = 0;
        let totalItems = 0;

        cartItemsContainer.innerHTML = '';

        if (cart.length === 0) {
            cartItemsContainer.innerHTML = `
                <p class="text-pink-600 text-center text-lg">
                    Your cart is empty.
                </p>`;
            cartSummary.classList.add('hidden');
            checkoutBtn.disabled = true;
        } else {
            cart.forEach((item, index) => {
                const itemTotal = item.price * item.quantity;
                total      += itemTotal;
                totalItems += item.quantity;

                const itemElement = document.createElement('div');
                itemElement.classList.add(
                    'flex','justify-between','items-center',
                    'border-b','border-pink-200','py-3'
                );
                itemElement.innerHTML = `
                    <div class="flex-grow">
                        <span class="font-semibold text-pink-700">${item.name}</span>
                        <span class="text-sm text-gray-500 block">@ ${formatDollar(item.price)}</span>
                    </div>
                    <div class="flex items-center space-x-3">
                        <button onclick="changeQuantity(${index}, -1)" class="text-pink-600 hover:text-pink-800 font-bold">-</button>
                        <span class="text-lg font-medium text-gray-700">${item.quantity}</span>
                        <button onclick="changeQuantity(${index}, 1)" class="text-pink-600 hover:text-pink-800 font-bold">+</button>
                    </div>
                    <div class="ml-4 text-lg font-semibold text-pink-600 w-32 text-right">
                        ${formatDollar(itemTotal)}
                    </div>
                    <button onclick="removeItem(${index})" class="ml-4 text-red-500 hover:text-red-700 font-bold text-xl leading-none">
                        &times;
                    </button>
                `;
                cartItemsContainer.appendChild(itemElement);
            });

            cartTotalDisplay.textContent = formatDollar(total);
            cartSummary.classList.remove('hidden');
            checkoutBtn.disabled = false;
        }
        return { total, totalItems };
    }

    // addToCart pakai nama + harga dari data-attribute
    function addToCart(name, price) {
        // CEK LOGIN DULU
        if (!IS_LOGGED_IN) {
            alert('Silakan login terlebih dahulu untuk memesan.');
            window.location.href = 'login.html';
            return;
        }

        price = parseFloat(price);
        if (isNaN(price)) price = 0;

        const existingItem = cart.find(item => item.name === name);

        if (existingItem) {
            existingItem.quantity += 1;
        } else {
            cart.push({ name, price, quantity: 1 });
        }

        alert(`🎉 ${name} telah ditambahkan ke keranjang!`);
        updateCartDisplay();
    }

    function changeQuantity(index, delta) {
        cart[index].quantity += delta;
        if (cart[index].quantity <= 0) {
            removeItem(index);
        } else {
            updateCartDisplay();
        }
    }

    function removeItem(index) {
        cart.splice(index, 1);
        updateCartDisplay();
    }

    function checkout() {
        // CEK LOGIN DULU
        if (!IS_LOGGED_IN) {
            alert('Silakan login terlebih dahulu sebelum checkout.');
            window.location.href = 'login.html';
            return;
        }

        if (cart.length === 0) {
            alert("Keranjang Anda kosong! Silakan tambahkan produk terlebih dahulu.");
            return;
        }

        const { total, totalItems } = updateCartDisplay();
        
        const message = `
            🛍️ Pesanan Berhasil! 🛍️
            
            Total Barang yang Dibeli: ${totalItems} item
            Total Harga: ${formatDollar(total)}
            
            Terima kasih banyak sudah belanja di Seoul & Beats Smtown Store! Semoga harimu menyenangkan.
        `;

        alert(message);
        
        cart = [];
        updateCartDisplay();
    }

    document.addEventListener('DOMContentLoaded', () => {
        // Ambil semua tombol Add to Cart (static + DB)
        const buttons = document.querySelectorAll('.add-to-cart-btn');

        buttons.forEach(btn => {
            btn.addEventListener('click', () => {
                const name  = btn.dataset.name;
                const price = btn.dataset.price;
                addToCart(name, price);
            });
        });

        const checkoutBtn = document.getElementById('checkout-btn');
        if (checkoutBtn) {
            checkoutBtn.addEventListener('click', checkout);
        }

        updateCartDisplay();
    });
    </script>
</body>
</html>
